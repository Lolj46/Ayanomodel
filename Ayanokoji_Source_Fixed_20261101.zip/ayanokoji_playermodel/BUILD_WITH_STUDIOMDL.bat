@echo off
setlocal
rem Usage: BUILD_WITH_STUDIOMDL.bat "C:\Program Files (x86)\Steam\steamapps\common\GarrysMod" "C:\path\to\studiomdl.exe"
if "%~1"=="" goto usage
if "%~2"=="" goto usage
set "GMODROOT=%~1"
set "STUDIOMDL=%~2"
set "GAMEDIR=%GMODROOT%\garrysmod"
if not exist "%GAMEDIR%\gameinfo.txt" (
  echo ERROR: garrysmod\gameinfo.txt not found in "%GAMEDIR%".
  exit /b 2
)
if not exist "%STUDIOMDL%" (
  echo ERROR: studiomdl executable not found: "%STUDIOMDL%"
  exit /b 3
)
if not exist "%GAMEDIR%\models\player" mkdir "%GAMEDIR%\models\player"
pushd "%~dp0modelsrc"
echo [1/2] Compiling Ayanokoji player model...
"%STUDIOMDL%" -game "%GAMEDIR%" -nop4 "ayanokoji.qc"
if errorlevel 1 (
  echo ERROR: studiomdl failed. Read the compiler output above.
  popd
  exit /b 4
)
popd
set "OUT=%GAMEDIR%\models\player\ayanokoji"
if not exist "%OUT%\ayanokoji.mdl" (
  echo ERROR: compiler returned success but ayanokoji.mdl was not created in "%OUT%".
  exit /b 5
)
set "ADDON=%~dp0models\player\ayanokoji"
if not exist "%ADDON%" mkdir "%ADDON%"
echo [2/2] Copying compiled model files into addon folder...
for %%F in ("%OUT%\ayanokoji.*") do (
  if exist "%%~F" copy /Y "%%~F" "%ADDON%\" >nul
)
echo Done. Addon folder now contains compiled model files.
echo Copy this package to garrysmod\addons, then test the model and ragdoll in-game.
exit /b 0
:usage
echo Usage: %~nx0 "GarrysMod root folder" "path to studiomdl.exe"
exit /b 1
