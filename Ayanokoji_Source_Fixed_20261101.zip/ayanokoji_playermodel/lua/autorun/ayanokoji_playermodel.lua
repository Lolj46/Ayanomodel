-- Kiyotaka Ayanokoji playermodel registration
if player_manager and list then
    player_manager.AddValidModel("Kiyotaka Ayanokoji", "models/player/ayanokoji/ayanokoji.mdl")
    list.Set("PlayerOptionsModel", "Kiyotaka Ayanokoji", "models/player/ayanokoji/ayanokoji.mdl")
end
