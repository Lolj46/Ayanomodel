KIYOTAKA AYANOKOJI — SOURCE BUILD PACKAGE

Исходники Playermodel под Garry's Mod с мужским ValveBiped skeleton.

В составе:
- modelsrc/ayanokoji.qc — основной QC.
- modelsrc/ayanokoji_reference.smd — исходная геометрия, 55 костей.
- modelsrc/ayanokoji_lod1.smd — LOD с 24 костями, без костей пальцев.
- modelsrc/ragdoll_pose.smd и ragdoll.smd — поза и collision hulls.
- modelsrc/includes/ — локальные QCI для helper bones, hierarchy, IK, hitbox и ragdoll.
- materials/models/player/ayanokoji/ — VMT, VTF и исходные PNG.
- lua/autorun/ayanokoji_playermodel.lua — Lua-регистрация модели.
- BUILD_WITH_STUDIOMDL.bat и BUILD_INSTRUCTIONS_RU.txt — сборка на Windows.

Это полный подготовленный SOURCE-пакет, но не готовый бинарный аддон: в нём нет .mdl/.vvd/.vtx/.phy, поскольку Source studiomdl отсутствует в рабочей среде. В QC подключена штатная мужская анимационная модель `m_anm.mdl`, которую должен предоставить установленный GMod.

Сначала изучи BUILD_INSTRUCTIONS_RU.txt и BUILD_STATUS_RU.txt. Совместимость с gDroid требует отдельного runtime-теста.


РИГ-ДИАГНОСТИКА: см. RIG_DIAGNOSTICS_RU.txt. Этот архив возвращает исходный Bip01/Pelvis SMD layout и содержит полный canonical Male commonbones.qci; это кандидат на исправление рассогласования с m_anm.mdl, ещё требующий компиляции и runtime-проверки.
